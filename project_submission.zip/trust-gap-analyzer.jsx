import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Star, MessageSquare } from 'lucide-react';

const TrustGapAnalyzer = () => {
  const [selectedProduct, setSelectedProduct] = useState('product1');

  // Sample data for different products
  const products = {
    product1: {
      name: "UltraPhone Pro Max",
      category: "Electronics",
      rawRating: 4.7,
      adjustedRating: 4.0,
      totalReviews: 2847,
      distribution: {
        5: 1823,
        4: 412,
        3: 156,
        2: 89,
        1: 367
      },
      botProbability: 35,
      sentimentBreakdown: {
        quality: 0.72,
        value: 0.45,
        shipping: 0.88,
        service: 0.61
      },
      reviews: [
        { stars: 5, text: "", credibility: 0.1, type: "bot" },
        { stars: 5, text: "Good", credibility: 0.2, type: "low-effort" },
        { stars: 5, text: "Screen is absolutely gorgeous, but battery life is honestly terrible. Died twice in one day with moderate use.", credibility: 0.9, type: "human", sentiment: 0.3 },
        { stars: 1, text: "Package arrived damaged, phone won't turn on. Customer service unhelpful.", credibility: 0.85, type: "human", sentiment: -0.8 },
        { stars: 5, text: "Amazing product! Fast shipping! Great price!", credibility: 0.25, type: "template" }
      ],
      trend: "declining",
      confidence: "high"
    },
    product2: {
      name: "Artisan Coffee Maker",
      category: "Kitchen Appliances",
      rawRating: 4.2,
      adjustedRating: 4.3,
      totalReviews: 487,
      distribution: {
        5: 234,
        4: 156,
        3: 58,
        2: 23,
        1: 16
      },
      botProbability: 8,
      sentimentBreakdown: {
        quality: 0.85,
        value: 0.78,
        shipping: 0.72,
        service: 0.81
      },
      reviews: [
        { stars: 5, text: "This machine makes incredible espresso. Build quality is solid, and the pressure gauge is accurate. Takes some learning but worth it.", credibility: 0.95, type: "human", sentiment: 0.9 },
        { stars: 4, text: "Great coffee, but it's quite loud in the morning. My roommates aren't fans.", credibility: 0.88, type: "human", sentiment: 0.6 },
        { stars: 3, text: "Works fine but cleaning is a hassle. Wish the drip tray was larger.", credibility: 0.82, type: "human", sentiment: 0.5 }
      ],
      trend: "improving",
      confidence: "medium"
    }
  };

  const product = products[selectedProduct];

  const getStarPercentage = (stars) => {
    const total = Object.values(product.distribution).reduce((a, b) => a + b, 0);
    return (product.distribution[stars] / total * 100).toFixed(1);
  };

  const getRatingColor = (rating) => {
    if (rating >= 4.5) return '#10b981';
    if (rating >= 4.0) return '#f59e0b';
    if (rating >= 3.0) return '#ef4444';
    return '#dc2626';
  };

  const getCredibilityColor = (credibility) => {
    if (credibility >= 0.7) return '#10b981';
    if (credibility >= 0.4) return '#f59e0b';
    return '#ef4444';
  };

  const getTrendIcon = () => {
    if (product.trend === 'improving') return <TrendingUp className="w-4 h-4" />;
    if (product.trend === 'declining') return <TrendingDown className="w-4 h-4" />;
    return null;
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
      color: '#e2e8f0',
      fontFamily: '"JetBrains Mono", "Courier New", monospace',
      padding: '2rem'
    }}>
      {/* Header */}
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        <div style={{ marginBottom: '3rem' }}>
          <h1 style={{
            fontSize: '2.5rem',
            fontWeight: '700',
            background: 'linear-gradient(90deg, #60a5fa 0%, #a78bfa 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            marginBottom: '0.5rem',
            letterSpacing: '-0.02em'
          }}>
            TRUST GAP ANALYZER
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.95rem', letterSpacing: '0.05em' }}>
            INTEGRITY-WEIGHTED REVIEW ENGINE • SIGNAL vs NOISE
          </p>
        </div>

        {/* Product Selector */}
        <div style={{ marginBottom: '2rem', display: 'flex', gap: '1rem' }}>
          {Object.keys(products).map((key) => (
            <button
              key={key}
              onClick={() => setSelectedProduct(key)}
              style={{
                padding: '0.75rem 1.5rem',
                background: selectedProduct === key ? '#3b82f6' : '#1e293b',
                border: selectedProduct === key ? '2px solid #60a5fa' : '2px solid #334155',
                borderRadius: '0.5rem',
                color: selectedProduct === key ? '#fff' : '#94a3b8',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: '600',
                transition: 'all 0.2s',
                letterSpacing: '0.02em'
              }}
              onMouseEnter={(e) => {
                if (selectedProduct !== key) {
                  e.target.style.borderColor = '#475569';
                }
              }}
              onMouseLeave={(e) => {
                if (selectedProduct !== key) {
                  e.target.style.borderColor = '#334155';
                }
              }}
            >
              {products[key].name}
            </button>
          ))}
        </div>

        {/* Main Dashboard Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '1.5rem',
          marginBottom: '2rem'
        }}>
          
          {/* Raw Rating Card */}
          <div style={{
            background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
            border: '2px solid #475569',
            borderRadius: '1rem',
            padding: '1.5rem',
            position: 'relative',
            overflow: 'hidden'
          }}>
            <div style={{
              position: 'absolute',
              top: 0,
              right: 0,
              width: '150px',
              height: '150px',
              background: 'radial-gradient(circle, rgba(96, 165, 250, 0.1) 0%, transparent 70%)',
              pointerEvents: 'none'
            }}></div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginBottom: '0.5rem', letterSpacing: '0.1em' }}>
              RAW RATING
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '1rem' }}>
              <span style={{ fontSize: '3rem', fontWeight: '700', color: getRatingColor(product.rawRating) }}>
                {product.rawRating.toFixed(1)}
              </span>
              <Star style={{ width: '1.5rem', height: '1.5rem', fill: getRatingColor(product.rawRating), color: getRatingColor(product.rawRating) }} />
            </div>
            <div style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
              {product.totalReviews.toLocaleString()} total reviews
            </div>
            <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
              Surface-level score (includes bots)
            </div>
          </div>

          {/* Adjusted Rating Card */}
          <div style={{
            background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a7b 100%)',
            border: '2px solid #3b82f6',
            borderRadius: '1rem',
            padding: '1.5rem',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 0 30px rgba(59, 130, 246, 0.2)'
          }}>
            <div style={{
              position: 'absolute',
              top: 0,
              right: 0,
              width: '150px',
              height: '150px',
              background: 'radial-gradient(circle, rgba(59, 130, 246, 0.2) 0%, transparent 70%)',
              pointerEvents: 'none'
            }}></div>
            <div style={{ fontSize: '0.75rem', color: '#93c5fd', marginBottom: '0.5rem', letterSpacing: '0.1em' }}>
              ✓ INTEGRITY SCORE
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '1rem' }}>
              <span style={{ fontSize: '3rem', fontWeight: '700', color: '#60a5fa' }}>
                {product.adjustedRating.toFixed(1)}
              </span>
              <Star style={{ width: '1.5rem', height: '1.5rem', fill: '#60a5fa', color: '#60a5fa' }} />
            </div>
            <div style={{ fontSize: '0.85rem', color: '#bfdbfe' }}>
              Weighted by verified sentiment
            </div>
            <div style={{ fontSize: '0.75rem', color: '#93c5fd', marginTop: '0.25rem' }}>
              The calculated truth
            </div>
          </div>

          {/* Bot Probability Card */}
          <div style={{
            background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
            border: `2px solid ${product.botProbability > 30 ? '#ef4444' : '#475569'}`,
            borderRadius: '1rem',
            padding: '1.5rem'
          }}>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginBottom: '0.5rem', letterSpacing: '0.1em' }}>
              BOT PROBABILITY
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '1rem' }}>
              <span style={{
                fontSize: '3rem',
                fontWeight: '700',
                color: product.botProbability > 30 ? '#ef4444' : '#f59e0b'
              }}>
                {product.botProbability}%
              </span>
              {product.botProbability > 30 && <AlertTriangle style={{ width: '1.5rem', height: '1.5rem', color: '#ef4444' }} />}
            </div>
            <div style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
              Non-human pattern detection
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '1rem' }}>
              {getTrendIcon()}
              <span style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase' }}>
                {product.trend} trend
              </span>
            </div>
          </div>
        </div>

        {/* Star Distribution */}
        <div style={{
          background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
          border: '2px solid #475569',
          borderRadius: '1rem',
          padding: '1.5rem',
          marginBottom: '2rem'
        }}>
          <h3 style={{ fontSize: '0.9rem', color: '#94a3b8', marginBottom: '1.5rem', letterSpacing: '0.1em' }}>
            STAR DISTRIBUTION BREAKDOWN
          </h3>
          {[5, 4, 3, 2, 1].map((stars) => (
            <div key={stars} style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '60px', display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.9rem' }}>
                <span>{stars}</span>
                <Star style={{ width: '0.9rem', height: '0.9rem', fill: '#fbbf24', color: '#fbbf24' }} />
              </div>
              <div style={{ flex: 1, background: '#0f172a', borderRadius: '0.5rem', height: '1.5rem', position: 'relative', overflow: 'hidden' }}>
                <div style={{
                  width: `${getStarPercentage(stars)}%`,
                  height: '100%',
                  background: stars >= 4 ? 'linear-gradient(90deg, #10b981 0%, #059669 100%)' : 
                             stars === 3 ? 'linear-gradient(90deg, #f59e0b 0%, #d97706 100%)' :
                             'linear-gradient(90deg, #ef4444 0%, #dc2626 100%)',
                  transition: 'width 0.5s ease-out'
                }}></div>
              </div>
              <div style={{ width: '100px', textAlign: 'right', fontSize: '0.85rem', color: '#94a3b8' }}>
                {product.distribution[stars]} ({getStarPercentage(stars)}%)
              </div>
            </div>
          ))}
        </div>

        {/* Sentiment Breakdown by Aspect */}
        <div style={{
          background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
          border: '2px solid #475569',
          borderRadius: '1rem',
          padding: '1.5rem',
          marginBottom: '2rem'
        }}>
          <h3 style={{ fontSize: '0.9rem', color: '#94a3b8', marginBottom: '1.5rem', letterSpacing: '0.1em' }}>
            ASPECT-BASED SENTIMENT ANALYSIS
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem' }}>
            {Object.entries(product.sentimentBreakdown).map(([aspect, score]) => (
              <div key={aspect}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span style={{ fontSize: '0.8rem', color: '#cbd5e1', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {aspect}
                  </span>
                  <span style={{ fontSize: '0.8rem', color: score >= 0.7 ? '#10b981' : score >= 0.5 ? '#f59e0b' : '#ef4444', fontWeight: '600' }}>
                    {(score * 100).toFixed(0)}%
                  </span>
                </div>
                <div style={{ background: '#0f172a', borderRadius: '0.5rem', height: '0.5rem', overflow: 'hidden' }}>
                  <div style={{
                    width: `${score * 100}%`,
                    height: '100%',
                    background: score >= 0.7 ? '#10b981' : score >= 0.5 ? '#f59e0b' : '#ef4444',
                    transition: 'width 0.5s ease-out'
                  }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Review Samples with Credibility */}
        <div style={{
          background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
          border: '2px solid #475569',
          borderRadius: '1rem',
          padding: '1.5rem'
        }}>
          <h3 style={{ fontSize: '0.9rem', color: '#94a3b8', marginBottom: '1.5rem', letterSpacing: '0.1em' }}>
            SAMPLE REVIEWS • CREDIBILITY SCORING
          </h3>
          {product.reviews.map((review, idx) => (
            <div key={idx} style={{
              background: '#0f172a',
              border: `1px solid ${review.type === 'bot' ? '#ef4444' : review.type === 'human' ? '#10b981' : '#f59e0b'}`,
              borderRadius: '0.75rem',
              padding: '1rem',
              marginBottom: '1rem'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.75rem' }}>
                <div style={{ display: 'flex', gap: '0.25rem' }}>
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      style={{
                        width: '1rem',
                        height: '1rem',
                        fill: i < review.stars ? '#fbbf24' : 'none',
                        color: i < review.stars ? '#fbbf24' : '#475569'
                      }}
                    />
                  ))}
                </div>
                <div style={{
                  fontSize: '0.7rem',
                  padding: '0.25rem 0.75rem',
                  borderRadius: '1rem',
                  background: getCredibilityColor(review.credibility) + '20',
                  color: getCredibilityColor(review.credibility),
                  border: `1px solid ${getCredibilityColor(review.credibility)}`,
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}>
                  {review.type} • {(review.credibility * 100).toFixed(0)}% credible
                </div>
              </div>
              {review.text ? (
                <p style={{ fontSize: '0.9rem', color: '#cbd5e1', lineHeight: '1.6', margin: 0 }}>
                  "{review.text}"
                </p>
              ) : (
                <p style={{ fontSize: '0.9rem', color: '#64748b', fontStyle: 'italic', margin: 0 }}>
                  [No written comment]
                </p>
              )}
              {review.sentiment !== undefined && (
                <div style={{ marginTop: '0.75rem', fontSize: '0.75rem', color: '#94a3b8' }}>
                  Sentiment Score: <span style={{ color: review.sentiment >= 0 ? '#10b981' : '#ef4444', fontWeight: '600' }}>
                    {review.sentiment >= 0 ? '+' : ''}{review.sentiment.toFixed(1)}
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer Stats */}
        <div style={{
          marginTop: '2rem',
          padding: '1.5rem',
          background: 'rgba(30, 41, 59, 0.5)',
          border: '1px solid #334155',
          borderRadius: '0.75rem',
          display: 'flex',
          justifyContent: 'space-around',
          flexWrap: 'wrap',
          gap: '1rem'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '0.7rem', color: '#64748b', marginBottom: '0.25rem', letterSpacing: '0.1em' }}>
              CONFIDENCE
            </div>
            <div style={{ fontSize: '1.1rem', fontWeight: '600', color: product.confidence === 'high' ? '#10b981' : '#f59e0b', textTransform: 'uppercase' }}>
              {product.confidence}
            </div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '0.7rem', color: '#64748b', marginBottom: '0.25rem', letterSpacing: '0.1em' }}>
              RATING DELTA
            </div>
            <div style={{ fontSize: '1.1rem', fontWeight: '600', color: product.rawRating > product.adjustedRating ? '#ef4444' : '#10b981' }}>
              {product.rawRating > product.adjustedRating ? '-' : '+'}{Math.abs(product.rawRating - product.adjustedRating).toFixed(1)}
            </div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '0.7rem', color: '#64748b', marginBottom: '0.25rem', letterSpacing: '0.1em' }}>
              ANALYSIS MODE
            </div>
            <div style={{ fontSize: '1.1rem', fontWeight: '600', color: '#60a5fa' }}>
              FUSION
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrustGapAnalyzer;