# Directives (Layer 1)

This directory contains **Standard Operating Procedures (SOPs)** written in Markdown.

## Purpose
Directives define **what to do** in natural language instructions. They are living documents that improve over time as you learn from execution.

## Structure
Each directive should include:

1. **Goal**: What this directive accomplishes
2. **Inputs**: What data/parameters are needed
3. **Tools**: Which execution scripts to use
4. **Outputs**: What's delivered at the end
5. **Edge Cases**: Known issues, rate limits, timing constraints, error handling

## Example Directive Template

```markdown
# [Action Name]

## Goal
What this accomplishes

## Inputs
- Input 1: Description
- Input 2: Description

## Tools
- `execution/script_name.py`: What it does

## Outputs
- Output 1: Where it goes
- Output 2: Format

## Edge Cases
- Rate limits: X requests/minute
- Known issues: Y
- Timing: Expects Z seconds
```

## Guidelines

- Write directives like you're instructing a mid-level employee
- Update directives when you learn new constraints or better approaches
- Keep them clear, concise, and actionable
- Don't create or overwrite directives without asking first
