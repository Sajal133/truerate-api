---
name: analyze_product_reviews
description: Analyze product reviews for credibility, sentiment, and adjusted ratings
version: 1.0.0
---

# Analyze Product Reviews

## Purpose
Process product reviews to calculate integrity-weighted ratings that account for bots, spam, sarcasm, and low-effort reviews.

## Inputs
| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `input_file` | string | Yes | Path to CSV or JSON file with reviews |
| `output_file` | string | No | Path to save results (defaults to `.tmp/results.json`) |
| `max_reviews` | integer | No | Limit number of reviews to process |

## Expected Schema
Reviews should have these fields:
```json
{
  "text": "Review text content",
  "stars": 5,
  "verified": true,
  "product_id": "ASIN or product identifier",
  "date": "2024-01-15"
}
```

For CSV files, map columns:
- `text` or `reviewText` → Review content
- `stars` or `overall` → Star rating (1-5)
- `asin` or `product_id` → Product identifier

## Procedure

### Step 1: Setup Environment
```bash
# Ensure dependencies are installed
cd /Users/sajal/FunTestig/Truth\ Gap\ Analyser
pip install vaderSentiment transformers torch spacy langdetect pandas numpy
```

### Step 2: Prepare Data
Place your review data in the `data/` directory:
```
data/
├── reviews.csv        # Your review file
└── ground_truth/      # Validation data (optional)
```

### Step 3: Run Analysis
```bash
cd execution

# Option A: Process CSV
python process_batch.py ../data/reviews.csv -o ../.tmp/results.json

# Option B: Process Amazon JSON (gzipped)
python process_batch.py ../data/Electronics_5.json.gz -o ../.tmp/results.json --max-rows 1000

# Option C: Custom weights (e.g., 30/70 instead of 20/80)
python process_batch.py ../data/reviews.csv -o ../.tmp/results.json --star-weight 0.3
```

### Step 4: Review Results
Results JSON structure:
```json
{
  "meta": {
    "generated_at": "2024-01-15T10:30:00",
    "total_reviews": 1000,
    "config": {"star_weight": 0.2, "sentiment_weight": 0.8}
  },
  "results": [
    {
      "original": {"text": "...", "stars": 5, "product_id": "..."},
      "analysis": {
        "sentiment": {"sentiment_score": 0.85, "confidence": 0.85},
        "credibility": {"score": 0.92, "classification": "human"},
        "sarcasm": {"is_sarcastic": false, "confidence": 0.1}
      },
      "result": {
        "adjusted_rating": 4.68,
        "original_stars": 5,
        "rating_delta": -0.32,
        "classification": "human",
        "is_sarcastic": false
      }
    }
  ]
}
```

## Outputs
| Output | Location | Description |
|--------|----------|-------------|
| `results.json` | `.tmp/results.json` | Full analysis results |
| Console summary | stdout | Product-level aggregations |

## Success Criteria
- [ ] All reviews processed without errors
- [ ] Bot detection rate: >15% flagged as bot/low-effort (typical for Amazon)
- [ ] Adjusted ratings differ from original by average 0.3-0.8 points
- [ ] MAE < 0.75 when validated against ground truth

## Error Handling

### Error: VADER not installed
```bash
pip install vaderSentiment
```

### Error: Can't load transformer model
```bash
# Use VADER-only mode
python process_batch.py input.csv -o output.json --mode vader
```

### Error: Memory issues with large files
```bash
# Process in chunks
python process_batch.py input.json -o output.json --max-rows 10000
```

### Error: Unicode decode error
Ensure your CSV/JSON is UTF-8 encoded:
```bash
file -I your_file.csv  # Check encoding
iconv -f ISO-8859-1 -t UTF-8 input.csv > output.csv
```

## Examples

### Quick Test (10 reviews)
```bash
cd execution
python process_batch.py ../data/sample_reviews.json --max-rows 10
```

### Full Amazon Dataset
```bash
# Download sample
wget -P ../data https://jmcauley.ucsd.edu/data/amazon_v2/categoryFilesSmall/Cell_Phones_and_Accessories_5.json.gz

# Process
python process_batch.py ../data/Cell_Phones_and_Accessories_5.json.gz -o ../.tmp/cell_phones_results.json --max-rows 5000
```

## Tools Used
1. `execution/analyze_sentiment.py` - VADER + Transformer hybrid
2. `execution/score_credibility.py` - Bot/spam detection
3. `execution/detect_sarcasm.py` - Sarcasm pattern matching
4. `execution/calculate_weighted_rating.py` - 20/80 fusion
5. `execution/process_batch.py` - Pipeline orchestration

## Related Directives
- None yet (this is the first directive)

## Changelog
- v1.0.0: Initial directive creation
